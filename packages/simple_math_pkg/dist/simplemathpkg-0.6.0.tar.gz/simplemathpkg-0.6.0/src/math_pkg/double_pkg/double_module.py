def double_ouptut(x: int):
    return 2*x
