def square_output(x: int):
	return x*x
